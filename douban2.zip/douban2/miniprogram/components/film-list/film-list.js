Component({
  properties:{
    film:{
      type:Object,
      value:{}
  }
}
})