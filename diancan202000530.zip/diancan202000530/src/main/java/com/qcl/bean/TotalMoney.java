package com.qcl.bean;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 作者：编程小石头
 */
@Data
public class TotalMoney {
    private String time;
    private BigDecimal totalMoney;
}
