package com.qcl.yichang;

/**
 * 编程小石头：2501902696（微信）
 */
public class DianCanAuthorizeException extends RuntimeException {
}
