package com.qcl.meiju;

/**
 * 编程小石头：2501902696（微信）
 */
public interface CodeNumEnum {
    Integer getCode();
}
