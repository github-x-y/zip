package com.qcl.global;

/**
 * 作者：编程小石头
 * 一些全局的常量
 */
public interface GlobalConst {
    String COOKIE_TOKEN = "bianchengxiaoshitou";//用来管理Cookie的key
    /*
    * 小程序相关
    * */
    String APPID="wx0cc0739e07111f62";//小程序的appid，记得换成你自己的
    String APPSECRET = "7b5a09cc87a1a5232009696584d14090";//小程序的appsecret，记得换成你自己的

}
