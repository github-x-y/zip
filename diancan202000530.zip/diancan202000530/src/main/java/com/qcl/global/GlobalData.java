package com.qcl.global;

/**
 * 作者：编程小石头
 */
public class GlobalData {
    public static int ADMIN_ID = -1;
}
